using Elder.Framework.Common.Base;
using Elder.Framework.Common.Enums;
using Elder.Framework.Common.Interfaces;
using Elder.Framework.Log.Helper;
using Elder.Framework.Log.Interfaces;
using System;
using System.Collections.Generic;

namespace Elder.Framework.MainFrame.Infra
{
    public class MainFramework : DisposableBase, IAppRegister, IInfraRegister, IAppProvider, IInfraProvider
    {
        private ILoggerPublisher _loggerPublisher;

        private readonly Dictionary<Type, IApplication> _persistentApps = new();
        private readonly Dictionary<Type, IInfrastructure> _persistentInfras = new();

        private readonly Dictionary<Type, IApplication> _sceneApps = new();
        private readonly Dictionary<Type, IInfrastructure> _sceneInfras = new();

        public bool TryRegisterInfra<T>(IInfrastructure targetInfra) where T : class, IInfrastructure
        {
            var infraContainer = targetInfra.LifeTimeType switch
            {
                LifeTimeScope.Persistent => _persistentInfras,
                LifeTimeScope.Scene => _sceneInfras,
                _ => null,
            };

            if (infraContainer == null)
                return false;

            return infraContainer.TryAdd(typeof(T), targetInfra);
        }
        public bool TryRegisterLogPublisher(ILoggerPublisher logPublisher)
        {
            _loggerPublisher = logPublisher;
            return _loggerPublisher != null ? true : false;
        }

        protected override void DisposeManagedResources()
        {
            DisposeSceneApps();
            DisposeSceneInfras();
            
            DisposePersistentApps();
            DisposePersistentInfras();

            DisposeLoggerPublisher();
        }

        private void DisposeSceneInfras()
        {
            foreach (var infra in _sceneInfras.Values)
            {
                if (infra is IDisposable disposable)
                    disposable.Dispose();
            }
            _sceneInfras.Clear();
        }

        private void DisposeSceneApps()
        {
            foreach (var app in _sceneApps.Values)
            {
                if (app is IDisposable disposable)
                    disposable.Dispose();
            }
            _sceneApps.Clear();
        }

        private void DisposePersistentInfras()
        {
            foreach (var infra in _persistentInfras.Values)
            {
                if (infra is IDisposable disposable)
                    disposable.Dispose();
            }
            _persistentInfras.Clear();
        }

        private void DisposePersistentApps()
        {
            foreach (var app in _persistentApps.Values)
            {
                if (app is IDisposable disposable)
                    disposable.Dispose();
            }
            _persistentApps.Clear();
        }



        private void DisposeLoggerPublisher()
        {
            if (_loggerPublisher is IDisposable disposable)
                disposable.Dispose();

            _loggerPublisher = null;
        }
    }
}