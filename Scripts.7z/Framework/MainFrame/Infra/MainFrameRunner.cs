using Elder.Framework.Common.Base;
using Elder.Framework.Common.Interfaces;
using Elder.Framework.Log.Helper;

namespace Elder.Framework.MainFrame.Infra
{
    public class MainFrameRunner : BehaviourBase
    {
        private MainFramework _mainFramework;

        private void Awake()
        {
            _mainFramework = new MainFramework();
        }

        public bool TryGetAppRegister(out IAppRegister appRegister)
        {
            appRegister = _mainFramework;
            return appRegister != null ? true : false;
        }

        public bool TryGetInfraRegister(out IInfraRegister infraRegister)
        {
            infraRegister = _mainFramework;
            return infraRegister != null ? true : false;
        }

        protected override void DisposeManagedResources()
        {
            DisposeMainFramework();
            CleanUpLogFacade();
        }

        private void DisposeMainFramework()
        {
            _mainFramework?.Dispose();
            _mainFramework = null;
        }

        private void CleanUpLogFacade()
        {
            LogFacade.CleanUp();
        }
    }
}