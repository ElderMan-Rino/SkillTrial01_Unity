namespace Elder.Framework.MainFrame.Constants
{
    public static class MainFrameConstants
    {
        public const string MAINFRAME_NAME = "[MainFrame]";
    }
}