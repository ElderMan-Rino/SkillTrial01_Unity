using Elder.Framework.Flux.Definitions;
using Elder.Framework.Flux.Interfaces;

namespace Elder.Framework.Flux.Helper
{
    public struct SubscriptionToken<T> where T : struct, IFluxMessage
    {
        private IFluxCancellable _fluxCancellable;
        private MessageHandler<T> _handler;

        public void Dispose()
        {
               
        }
    }
}