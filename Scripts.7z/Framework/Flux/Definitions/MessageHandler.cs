namespace Elder.Framework.Flux.Definitions
{
    public delegate void MessageHandler<T>(in T message);
}