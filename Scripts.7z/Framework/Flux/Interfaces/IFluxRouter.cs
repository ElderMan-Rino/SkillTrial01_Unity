using Elder.Framework.Common.Interfaces;
using Elder.Framework.Flux.Definitions;
using Elder.Framework.Flux.Helper;
using System;

namespace Elder.Framework.Flux.Interfaces
{
    public interface IFluxRouter : IApplication
    {
        public SubscriptionToken<T> Subscribe<T>(MessageHandler<T> handler) where T : struct, IFluxMessage;
        public void Publish<T>(in T message) where T : struct, IFluxRouter;
    }
}