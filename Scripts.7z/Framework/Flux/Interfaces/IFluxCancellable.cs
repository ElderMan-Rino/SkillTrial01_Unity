using Elder.Framework.Flux.Definitions;

namespace Elder.Framework.Flux.Interfaces
{
    public interface IFluxCancellable
    {
        public void Unsubscribe<T>(MessageHandler<T> handler, FluxPhase phase) where T : struct, IFluxMessage;
    }
}