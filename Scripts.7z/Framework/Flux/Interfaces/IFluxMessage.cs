namespace Elder.Framework.Flux.Interfaces
{
    public interface IFluxMessage {}
}