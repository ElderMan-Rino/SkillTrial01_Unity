using Elder.Framework.Common.Base;
using Elder.Framework.Common.Enums;
using Elder.Framework.Flux.Definitions;
using Elder.Framework.Flux.Helper;
using Elder.Framework.Flux.Interfaces;
using System;
using System.Collections.Generic;

namespace Elder.Framework.Flux.App
{
    public class FluxRouter : AppBase, IFluxRouter, IFluxCancellable
    {
        private Dictionary<Type, List<Delegate>> _messageHandler;

        public override LifeTimeScope LifeTimeType => LifeTimeScope.Persistent;

        public void Publish<T>(in T message) where T : struct, IFluxRouter
        {
            throw new NotImplementedException();
        }

        public SubscriptionToken<T> Subscribe<T>(MessageHandler<T> handler) where T : struct, IFluxMessage
        {
            throw new NotImplementedException();
        }

        public void Unsubscribe<T>(MessageHandler<T> handler, FluxPhase phase) where T : struct, IFluxMessage
        {
            throw new NotImplementedException();
        }

    }
}