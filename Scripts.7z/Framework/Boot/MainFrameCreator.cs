using Elder.Framework.Common.Enums;
using Elder.Framework.Log.Helper;
using Elder.Framework.Log.Infra;
using Elder.Framework.Log.Interfaces;
using Elder.Framework.MainFrame.Constants;
using Elder.Framework.MainFrame.Infra;
using System.Collections.Generic;
using UnityEngine;

namespace Elder.Framework.Boot
{
    public class MainFrameCreator
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSplashScreen)]
        public static void Entry()
        {
            CreateMainFrameRunner();
        }

        private static void CreateMainFrameRunner()
        {
            var mainFrameName = MainFrameConstants.MAINFRAME_NAME;
            if (GameObject.Find(mainFrameName))
                return;

            var go = new GameObject(mainFrameName);
            var runner = go.AddComponent<MainFrameRunner>();
            SetupCoreServices(runner);
        }

        private static void SetupCoreServices(MainFrameRunner runner)
        {
            if (!runner.TryGetInfraRegister(out var register)) // ������ Helper �޼��� ȣ��
                return;

            var loggerService = new LoggerService(new List<ILogAdapter> { new UnityLogAdapter() });
            if (!register.TryRegisterLogPublisher(loggerService))
                return;

            LogFacade.InjectProvider(loggerService);
        }
    }
}