using Elder.Framework.Common.Base;
using Elder.Framework.MainFrame.Constants;
using Elder.Framework.MainFrame.Infra;
using UnityEngine;

namespace Elder.Framework.Boot.Base
{
    public abstract class BootstrapperBase : BehaviourBase
    {
        protected virtual void InjectSystems(MainFrameRunner mainFrameRunner)
        {
            // �������� �� System(App, Infra, Domain)�� �߰� 
            // �ڽĿ��� Ȯ�� 
        }
    }
}