using Elder.Framework.Boot.Base;
using Elder.Framework.MainFrame.Constants;
using Elder.Framework.MainFrame.Infra;
using UnityEngine;

namespace Elder.Framework.Boot.Initialize
{

    public class InitializeBootStrapper : BootstrapperBase
    {
        private void Awake()
        {
            FindAndInjectRunner();
        }

        private void FindAndInjectRunner()
        {
            var mainFrameName = MainFrameConstants.MAINFRAME_NAME;
            var mainFrameObject = GameObject.Find(mainFrameName);
            if (!mainFrameObject)
                return;

            var mainFrameRunner = mainFrameObject.GetComponent<MainFrameRunner>();
            if (!mainFrameRunner)
                return;

            InjectSystems(mainFrameRunner);
        }


        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }

        protected override void FinalizeDispose()
        {

        }

        protected override void OnDisposing()
        {

        }
    }
}