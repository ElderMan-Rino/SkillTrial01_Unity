namespace Elder.Framework.Common.Enums
{
    public enum LogLevel
    {
        Debug,
        Info,
        Warning,
        Error
    }
}