namespace Elder.Framework.Common.Enums
{
    public enum LifeTimeScope
    {
        Persistent,
        Scene,
    }
}