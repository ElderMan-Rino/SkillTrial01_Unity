using Elder.Framework.Common.Enums;

namespace Elder.Framework.Common.Interfaces
{
    public interface IInfrastructure 
    {
        public LifeTimeScope LifeTimeType { get; }
        public bool TryInitialize(IDomainProvider domainProvider, IAppProvider appProvider, IInfraProvider infraProvider);
        public bool TryPostInitialize();
    }
}