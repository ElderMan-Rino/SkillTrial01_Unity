namespace Elder.Framework.Common.Interfaces
{
    public interface IDomainProvider 
    {
        
    }
}