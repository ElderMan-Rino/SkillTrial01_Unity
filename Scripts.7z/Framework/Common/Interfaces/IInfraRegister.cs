using Elder.Framework.Log.Interfaces;

namespace Elder.Framework.Common.Interfaces
{
    public interface IInfraRegister
    {
        public bool TryRegisterInfra<T>(IInfrastructure targetInfra) where T : class, IInfrastructure;
        public bool TryRegisterLogPublisher(ILoggerPublisher logPublisher);
    }
}