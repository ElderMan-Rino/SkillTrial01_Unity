namespace Elder.Framework.Common.Interfaces
{
    public interface IAppRegister 
    {
        
    }
}