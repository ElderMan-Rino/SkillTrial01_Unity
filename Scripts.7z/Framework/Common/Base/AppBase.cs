using Elder.Framework.Common.Enums;
using Elder.Framework.Common.Interfaces;

namespace Elder.Framework.Common.Base
{
    public abstract class AppBase : DisposableBase, IApplication
    {
        public abstract LifeTimeScope LifeTimeType { get; }

    }
}