using Elder.Framework.Common.Enums;
using Elder.Framework.Common.Interfaces;

namespace Elder.Framework.Common.Base
{
    public abstract class InfraBase : DisposableBase, IInfrastructure
    {
        private IDomainProvider _domainProvider;
        private IAppProvider _appProvider;
        private IInfraProvider _infraProvider;

        public abstract LifeTimeScope LifeTimeType { get; }

        public bool TryInitialize(IDomainProvider domainProvider, IAppProvider appProvider, IInfraProvider infraProvider)
        {
            InjectDomainProvider(domainProvider);
            InjectAppProvider(appProvider);
            InjectInfraProvider(infraProvider);
            return true;
        }

        private void InjectDomainProvider(IDomainProvider domainProvide)
        {
            _domainProvider = domainProvide;
        }

        private void InjectAppProvider(IAppProvider appProvider)
        {
            _appProvider = appProvider;
        }

        private void InjectInfraProvider(IInfraProvider infraProvider)
        {
            _infraProvider = infraProvider;
        }

        public bool TryPostInitialize()
        {
            return true;
        }

        protected override void DisposeManagedResources()
        {
            ClearDomainProvider();
            ClearAppProvider();
            ClearInfraProvider();
            base.DisposeManagedResources();
        }

        private void ClearDomainProvider()
        {
            _domainProvider = null;
        }

        private void ClearAppProvider()
        {
            _appProvider = null;
        }

        private void ClearInfraProvider()
        {
            _infraProvider = null;
        }
    }
}