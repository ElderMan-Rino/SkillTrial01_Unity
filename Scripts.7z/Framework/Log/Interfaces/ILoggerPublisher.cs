using Elder.Framework.Common.Interfaces;
using System;

namespace Elder.Framework.Log.Interfaces
{
    public interface ILoggerPublisher : IInfrastructure
    {
        public ILoggerEx GetLogger<T>() where T : class;
        public ILoggerEx GetLogger(Type type);
    }
}