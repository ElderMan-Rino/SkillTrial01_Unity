using Elder.Framework.Log.Infra;

namespace Elder.Framework.Log.Interfaces
{
    public interface ILogAdapter 
    {
        public void DispatchLogEvent(in LogEvent logEvent);
    }
}