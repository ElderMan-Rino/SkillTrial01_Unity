using Elder.Framework.Common.Base;
using Elder.Framework.Common.Enums;
using Elder.Framework.Log.Interfaces;
using System;
using System.Collections.Generic;

namespace Elder.Framework.Log.Infra
{
    public class LoggerService : InfraBase, ILoggerPublisher
    {
        private readonly Dictionary<Type, LoggerEX> _loggerContainer = new();
        private readonly List<ILogAdapter> _logAdapters;

        public override LifeTimeScope LifeTimeType => LifeTimeScope.Persistent;

        public LoggerService(List<ILogAdapter> logAdapters)
        {
            _logAdapters = logAdapters;
        }

        public ILoggerEx GetLogger<T>() where T : class
        {
            return GetLogger(typeof(T));
        }

        public ILoggerEx GetLogger(Type type)
        {
            if (!_loggerContainer.TryGetValue(type, out var targetLogger))
            {
                targetLogger = new LoggerEX(type, PublishLogEvent);
                _loggerContainer[type] = targetLogger;
            }
            return targetLogger;
        }

        private void PublishLogEvent(LogEvent logEvent)
        {
            foreach (var adapater in _logAdapters)
                adapater.DispatchLogEvent(logEvent);
        }

        protected override void DisposeManagedResources()
        {
            DisposeLogAdapters();
            DisposeLoggerEXContainer();
        }

        private void DisposeLogAdapters()
        {
            foreach (var adapter in _logAdapters)
            {
                if (adapter is IDisposable disposableAdapter)
                    disposableAdapter.Dispose();
            }
            _logAdapters.Clear();
        }

        private void DisposeLoggerEXContainer()
        {
            foreach (var loggerEX in _loggerContainer.Values)
                loggerEX.Dispose();
            _loggerContainer.Clear();
        }
    }
}