using Elder.Framework.Common.Base;
using Elder.Framework.Log.Interfaces;
using System;

namespace Elder.Framework.Log.Infra
{
    public class LoggerEX : DisposableBase, ILoggerEx
    {
        private Type _ownerType;
        private Action<LogEvent> _logAction;

        public LoggerEX(Type ownerType, Action<LogEvent> logAction)
        {
            _ownerType = ownerType;
            _logAction = logAction;
        }

        [System.Diagnostics.Conditional("ENABLE_LOGGING")]
        private void PublishLog(in LogEvent logEvent)
        {
            _logAction?.Invoke(logEvent);
        }

        public void Debug(string message)
        {
            PublishLog(LogEvent.Debug(_ownerType, message));
        }

        public void Info(string message)
        {
            PublishLog(LogEvent.Info(_ownerType, message));
        }

        public void Warning(string message)
        {
            PublishLog(LogEvent.Warning(_ownerType, message));
        }

        public void Error(string message)
        {
            PublishLog(LogEvent.Error(_ownerType, message));
        }

        protected override void DisposeManagedResources()
        {
            ClearLogAction();
        }

        private void ClearLogAction()
        {
            _logAction = null;
        }
    }
}