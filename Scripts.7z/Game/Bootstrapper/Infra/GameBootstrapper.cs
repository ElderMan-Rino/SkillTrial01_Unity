using UnityEngine;
using Elder.Framework.Boot.Base;

namespace Elder.Game.Boot.Infra
{
    public class GameBootstrapper : BootstrapperBase
    {
        protected override void OnDisposing()
        {

        }

        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }

        protected override void FinalizeDispose()
        {

        }
    }
}