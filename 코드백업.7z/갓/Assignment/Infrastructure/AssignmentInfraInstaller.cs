using Elder.Assignment.InGame.Infrastructure;
using Elder.Assignment.InGame.Interfaces;
using Elder.Platform.CoreFrame.Infrastructure.Factories;

namespace Elder.Assignment.Infrastructure
{
    public class AssignmentInfraInstaller 
    {
        public void Install(InfrastructureFactory infraFactory)
        {
            infraFactory.Register<IInGameInfra>(() => new InGameInfrastructure());
        }
    }
}