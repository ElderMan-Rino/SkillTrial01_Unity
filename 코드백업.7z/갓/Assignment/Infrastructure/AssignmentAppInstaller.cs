using Elder.Assignment.InGame.Application;
using Elder.Assignment.InGame.Interfaces;
using Elder.Core.CoreFrame.Application;
using Elder.Core.Preload.Application;
using Elder.Core.Preload.Interfaces;

namespace Elder.Assignment.Infrastructure
{
    public class AssignmentAppInstaller 
    {
        public void Install(ApplicationFactory appFactory)
        {
            appFactory.Register<IPreloadApp>(() => new PreloadApplication());
            appFactory.Register<IInGameApp>(() => new InGameApplication());
        }
    }
}