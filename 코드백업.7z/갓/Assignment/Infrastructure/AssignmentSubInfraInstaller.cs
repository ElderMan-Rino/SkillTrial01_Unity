using Elder.Platform.CoreFrame.Infrastructure.Factories;

namespace Elder.Assignment.Infrastructure
{
    public class AssignmentSubInfraInstaller
    {
        public void Install(SubInfrastructureFactory subInfraFactory)
        {

        }
    }
}