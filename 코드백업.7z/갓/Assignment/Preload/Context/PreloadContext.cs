using Elder.Core.Preload.Interfaces;
using Elder.Platform.Common.BaseClasses;

namespace Elder.Assignment.Preload.Context
{
    public class PreloadContext : ContextBase
    {
        protected override void Awake()
        {
            base.Awake();
            RequirePreloadApp();
        }

        private void RequirePreloadApp()
        {
            if (!TryRequireApplication<IPreloadApp>())
            {
                _logger.Error($"Failed to require application. Target Type: {typeof(IPreloadApp).Name}");
                return;
            }
        }

        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}