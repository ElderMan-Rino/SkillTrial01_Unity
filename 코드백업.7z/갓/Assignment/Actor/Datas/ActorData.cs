using System;
using System.Collections.Generic;

namespace Elder.Assignment.Actor.Data
{
    [Serializable]
    public struct ActorData
    {
        public int Index;
        public int StatDataIndex;
        public List<int> SkillDataIndexes; // ��Ÿ ���� (Indexs -> Indexes)
        public string PrefabKey;
    }
}