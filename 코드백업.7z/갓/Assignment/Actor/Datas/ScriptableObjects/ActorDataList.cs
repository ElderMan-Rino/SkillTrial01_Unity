using Elder.Assignment.Actor.Data;
using System.Collections.Generic;
using UnityEngine;

namespace Elder.Assignment.Actor.Datas.ScriptableObjects
{
    [CreateAssetMenu(fileName = "ActorDataList", menuName = "Elder/Data/ActorDataList")]
    public class ActorDataList : ScriptableObject
    {
        [SerializeField] private List<ActorData> _actorDatas;
        public List<ActorData> ActorDatas => _actorDatas;
    }
}