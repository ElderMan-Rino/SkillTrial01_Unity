using Elder.Assignment.InGame.Interfaces;
using Elder.Core.ActorSpawner.Data;
using Elder.Core.ActorSpawner.Interfaces;
using Elder.Platform.Common.BaseClasses;
using System.Collections.Generic;
using UnityEngine;

namespace Elder.Assignment.InGame.Context
{
    public class InGameContext : ContextBase, ISpawnDataProvider
    {
        [SerializeField] private Transform _actorRoot;
        [SerializeField] private Transform _userSpawnPoint;
        [SerializeField] private Transform _aiSpawnPoint;


        protected override void Awake()
        {
            base.Awake();
            InitializeInGame();
        }

        private void InitializeInGame()
        {
            if (!TrySetupInGameInfra())
                return;
            
            if (!TryRequireInGameApp())
                return;
        }

        private bool TrySetupInGameInfra()
        {
            if (!TryEnsureInfrastructure<IInGameInfra>(out var targetInfra))
            {
                _logger.Error($"Failed to register Infrastructure. Target Type: {typeof(IInGameInfra).Name}");
                return false;
            }
            targetInfra.SetSpawnInfo(this);
            return true;
        }

        private bool TryRequireInGameApp()
        {
            if (!TryRequireApplication<IInGameApp>())
            {
                _logger.Error($"Failed to require application. Target Type: {typeof(IInGameApp).Name}");
                return false;
            }
            return true;
        }

        public bool TryGetSpawnInfos(out IList<SpawnInfo> spawnInfo)
        {
            spawnInfo = new List<SpawnInfo>();
            spawnInfo.Add(new SpawnInfo(1, _userSpawnPoint, _actorRoot));
            spawnInfo.Add(new SpawnInfo(2, _aiSpawnPoint, _actorRoot));
            return true;
        }

        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }

      
    }
}