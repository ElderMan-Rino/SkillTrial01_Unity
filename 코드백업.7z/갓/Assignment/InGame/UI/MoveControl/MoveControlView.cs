using Elder.Platform.UI.BaseClasses;
using R3;
using UnityEngine;
using UnityEngine.UI;

namespace Elder.Assignment.InGame.UI.MoveControl
{
    public class MoveControlView : ViewBase
    {
        private Observable<Unit> _onLeftClicked;
        private Observable<Unit> _onRightClicked;

        [SerializeField] private Button _left;
        [SerializeField] private Button _right;


        protected override void Awake()
        {
            base.Awake();
            InitializeButtonEvents();
        }
       
        private void InitializeButtonEvents()
        {
            _onLeftClicked = _left.OnClickAsObservable();
            _onRightClicked = _right.OnClickAsObservable();
        }

        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}