using Elder.Platform.UI.BaseClasses;
using UnityEngine;
using System.Text;
using TMPro;

namespace Elder.Assignment.InGame.UI.Timer
{
    public class GameTimer : ViewBase
    {
        private StringBuilder _timerStringBuilder;

        [SerializeField] private TextMeshPro _timer;

        protected override void Awake()
        {
            base.Awake();
            InitializeTimerStringBuilder();
        }

        private void InitializeTimerStringBuilder()
        {
            _timerStringBuilder = new();
        }

        private void UpdateTimer(long leftTime)
        {
            _timer.SetText("");
        }

        protected override void DisposeManagedResources()
        {
            DisposeTimeStringBuilder();
            base.DisposeManagedResources();
        }

        private void DisposeTimeStringBuilder()
        {
            _timerStringBuilder.Clear();
            _timerStringBuilder = null;
        }
    }
}