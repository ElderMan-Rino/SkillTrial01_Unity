using Cysharp.Threading.Tasks;
using Elder.Assignment.InGame.Interfaces;
using Elder.Core.ActorManager.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.GameAsset.Interfaces;

namespace Elder.Assignment.InGame.Application
{
    public class InGameApplication : ApplicationBase, IInGameApp
    {
        private IInGameInfra _inGameInfra;
        private IActorManagerApp _actorManagerApp;
        private IAssetRepository _assetRepository;

        public override ApplicationType AppType => ApplicationType.Scene;

        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            if (!base.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;

            RequireInGameInfra();
            return true;
        }

        private void RequireInGameInfra()
        {
            RequireInfrastructure<IInGameInfra>();
        }

        public override bool TryPostInitialize()
        {
            if (!base.TryPostInitialize())
                return false;

            if (!TryBindInGameInfra())
                return false;

            RunGameFlow().Forget();
            return true;
        }

        private bool TryBindInGameInfra()
        {
            if (!TryGetInfrastructure<IInGameInfra>(out var inGameInfra))
            {
                _logger.Error("Failed to retrieve IInGameInfra from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _inGameInfra = inGameInfra;
            return _inGameInfra != null;
        }

        private async UniTask RunGameFlow()
        {
            if (!TryGetInGameInfra(out var inGameInfra))
                return;
        }

        private bool TryGetInGameInfra(out IInGameInfra inGameInfra)
        {
            if (!TryGetInfrastructure<IInGameInfra>(out inGameInfra))
            {
                _logger.Error("Failed to retrieve IInGameInfra from infrastructure. It may not be initialized or registered.");
                return false;
            }
            return true;
        }



        protected override void DisposeSubTokens()
        {

        }

        protected override void DisposeManagedResources()
        {
            ClearInGmaeInfra();
            base.DisposeManagedResources();
        }

        private void ClearInGmaeInfra()
        {
            _inGameInfra = null;
        }
    }
}