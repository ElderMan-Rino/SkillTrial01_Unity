using Elder.Core.ActorSpawner.Interfaces;
using Elder.Core.Common.Interfaces;

namespace Elder.Assignment.InGame.Interfaces
{
    public interface IInGameInfra : IInfrastructure
    {
        public ISpawnDataProvider SpawnInfo { get; }
        public void SetSpawnInfo(ISpawnDataProvider spawnInfo);
    }
}