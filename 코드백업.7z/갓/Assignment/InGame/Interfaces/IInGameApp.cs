using Elder.Core.Common.Interfaces;

namespace Elder.Assignment.InGame.Interfaces
{
    public interface IInGameApp : IApplication
    {

    }
}