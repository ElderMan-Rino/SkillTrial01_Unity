using Elder.Assignment.InGame.Interfaces;
using Elder.Core.ActorSpawner.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;

namespace Elder.Assignment.InGame.Infrastructure
{
    public class InGameInfrastructure : InfrastructureBase, IInGameInfra
    {
        private ISpawnDataProvider _spawnInfo;

        public override InfrastructureType InfraType => InfrastructureType.Scene;
        public ISpawnDataProvider SpawnInfo => _spawnInfo;

        public void SetSpawnInfo(ISpawnDataProvider spawnInfo)
        {
            _spawnInfo = spawnInfo;
        }
    }
}