using System.Collections.Generic;
using UnityEngine;

namespace Elder.Assignment.Skill.Datas.ScriptableObjects
{
    [CreateAssetMenu(fileName = "SkillDataList", menuName = "Elder/Data/SkillDataList")]
    public class SkillDataList : ScriptableObject
    {
        [SerializeField] private List<SkillData> _skillDatas;
        public List<SkillData> SkillDatas => _skillDatas;
    }
}