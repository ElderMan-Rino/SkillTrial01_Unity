using System;

namespace Elder.Assignment.Skill.Datas
{
    [Serializable]
    public struct SkillData
    {
        public int Index;
        public string SkillIcon;
        public float CoolTime;
        public string PrefabKey; // Ʈ�� �������� Ű 
    }
}