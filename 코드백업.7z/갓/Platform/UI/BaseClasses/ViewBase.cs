using Elder.Core.Common.Enums;
using Elder.Platform.Common.BaseClasses;
using System.Collections.Generic;

namespace Elder.Platform.UI.BaseClasses
{
    public abstract class ViewBase : BehaviourBase
    {
        protected virtual ViewType _viewType => ViewType.None;

        private Dictionary<long, ViewBase> _widgets;

        protected virtual void Awake()
        {
            InitializeWidgetContainer();
            RegisterWidgets();
        }

        private void InitializeWidgetContainer()
        {
            _widgets = new();
        }

        private void RegisterWidgets()
        {
            var widgets = GetComponentsInChildren<ViewBase>();
            foreach (var widget in widgets)
                _widgets.TryAdd(widget.GetHashCode(), widget);
        }

        protected override void DisposeManagedResources()
        {
            DisposeWidgets();
        }

        private void DisposeWidgets()
        {
            if (_widgets == null)
                return;
         
            foreach (var widget in _widgets.Values)
                widget.Dispose();
            _widgets.Clear();
            _widgets = null;
        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}