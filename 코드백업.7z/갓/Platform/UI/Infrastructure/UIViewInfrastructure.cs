using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.UI.Interfaces;
using System;

namespace Elder.Platform.UI.Infrastructure
{
    [Serializable]
    public class UIViewInfrastructure : InfrastructureBase, IUIViewInfrastructure
    {
        public override InfrastructureType InfraType => InfrastructureType.Persistent;

        public void RegisterViews()
        {

        }
    }
}