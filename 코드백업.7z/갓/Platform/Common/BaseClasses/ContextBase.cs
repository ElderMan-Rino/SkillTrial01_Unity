using Elder.Core.Common.Constant;
using Elder.Core.Common.Interfaces;
using Elder.Core.Logging.Helpers;
using Elder.Core.Logging.Interfaces;
using Elder.Platform.CoreFrame.Presentation;
using UnityEngine;

namespace Elder.Platform.Common.BaseClasses
{
    public abstract class ContextBase : BehaviourBase
    {
        protected ILoggerEx _logger;
        protected IContextAdapter _contextAdapter;

        protected virtual void Awake()
        {
            InitializeContextBase();
        }

        private void InitializeContextBase()
        {
            if (!TryBindLogger())
                return;

            if (!TryBindContextAdapter())
                return;
        }

        private bool TryBindLogger()
        {
            _logger = LogFacade.GetLoggerFor(this.GetType());
            return _logger != null;
        }

        private bool TryBindContextAdapter()
        {
            var mainFramework = GameObject.Find(CoreConstants.MAIN_FRAMEWORK_NAME);
            if (!mainFramework)
            {
                _logger.Error($"Failed to find MainFramework GameObject. Search Name: {CoreConstants.MAIN_FRAMEWORK_NAME}");
                return false;
            }

            var coreFrame = mainFramework.GetComponent<CoreFrameRunner>();
            if (coreFrame == null)
            {
                _logger.Error($"Failed to get CoreFrameRunner component from GameObject '{CoreConstants.MAIN_FRAMEWORK_NAME}'.");
                return false;
            }

            _contextAdapter = coreFrame.ContextAdapter;
            return _contextAdapter != null;
        }

        protected bool TryRequireApplication<T>() where T : class, IApplication
        {
            if (_contextAdapter == null)
                return false;
            
            if (!_contextAdapter.TryRequireApplication<T>())
            {
                _logger.Error($"Failed to require application via CoreFrameRunner. Target Type: {typeof(T).Name}");
                return false;
            }
            return true;
        }

        protected bool TryEnsureApplication<T>(out T targetApp) where T : class, IApplication
        {
            targetApp = null;
            if (_contextAdapter == null)
                return false;

            if (!_contextAdapter.TryRequireApplication<T>())
            {
                _logger.Error($"Failed to require application via CoreFrameRunner. Target Type: {typeof(T).Name}");
                return false;
            }
            return true;
        }

        protected bool TryEnsureInfrastructure<T>(out T targetInfra) where T : class, IInfrastructure
        {
            targetInfra = null;
            if (_contextAdapter == null)
                return false;

            if (!_contextAdapter.TryEnsureInfrastructure<T>(out targetInfra))
            {
                _logger.Error($"Failed to register infra via CoreFrameRunner. Target Type: {typeof(T).Name}");
                return false;
            }
            return true;
        }


        protected override void PreDispose()
        {
            ClearLogger();
        }

        private void ClearLogger()
        {
            _logger = null;
        }

        protected override void DisposeManagedResources()
        {
            ClearContextAdapter();
        }

        private void ClearContextAdapter()
        {
            _contextAdapter = null;
        }
    }
}