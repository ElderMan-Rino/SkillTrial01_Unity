using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.GameAsset.Interfaces;
using System.Collections.Generic;
using UnityEngine;

namespace Elder.Platform.GameAsset.Infrastructure
{
    public class AssetRepository : InfrastructureBase, IAssetRepository
    {
        private Dictionary<System.Type, Dictionary<string, Object>> _assets;

        public override InfrastructureType InfraType => InfrastructureType.Persistent;

        public override bool TryInitialize(IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister, ISubInfrastructureCreator subInfraCreator, IApplicationProvider appProvider)
        {
            if (!base.TryInitialize(infraProvider, infraRegister, subInfraCreator, appProvider))
                return false;

            InitializeAssetContainer();
            return true;
        }

        private void InitializeAssetContainer()
        {
            _assets = new();
        }


        public bool TryGetAsset<T>(string key, out T targetAsset) where T : class
        {
            targetAsset = null;
            var type = typeof(T);
            if (!_assets.TryGetValue(type, out var assetsByType))
                return false;

            if (!assetsByType.TryGetValue(key, out var asset))
                return false;

            targetAsset = asset as T;
            return targetAsset != null;
        }

        public bool TryAddAsset<T>(string key, T targetAsset) where T : class
        {
            var type = typeof(T);
            if (!_assets.TryGetValue(type, out var assetsByType))
            {
                assetsByType = new();
                _assets[type] = assetsByType;
            }

            if (targetAsset is not Object unityObject)
                return false;

            return assetsByType.TryAdd(key, unityObject);
        }

        protected override void DisposeManagedResources()
        {
            DisposeAssets();
            base.DisposeManagedResources();
        }

        private void DisposeAssets()
        {
            foreach (var assetsByType in _assets.Values)
                assetsByType.Clear();
            _assets.Clear();
            _assets = null;
        }
    }
}