using Elder.Core.Common.BaseClasses;

namespace Elder.Platform.Actors.BaseClasses.Components
{
    public abstract class BaseActorComponent : DisposableBase
    {
        protected BaseActor _owner;

        public void SetOwner(BaseActor owner)
        {
            _owner = owner;
        }

        public abstract void InitializeComponent();
        
        protected override void DisposeManagedResources()
        {

        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}