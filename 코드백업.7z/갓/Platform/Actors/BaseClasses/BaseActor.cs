using Elder.Core.Common.BaseClasses;
using Elder.Platform.Actors.BaseClasses.Components;
using System;
using System.Collections.Generic;

namespace Elder.Platform.Actors.BaseClasses
{
    public abstract class BaseActor : DisposableBase
    {
        private Dictionary<Type, BaseActorComponent> _componentContainer;

        public BaseActor()
        {
            InitializeComponentContainer();
        }

        private void InitializeComponentContainer()
        {
            _componentContainer = new();
        }

        protected bool TryAddComponent<T>() where T : BaseActorComponent, new()
        {
            var type = typeof(T);
            if (_componentContainer.ContainsKey(type))
                return false;

            _componentContainer.Add(type, CreateComponent<T>());
            return true;
        }

        private BaseActorComponent CreateComponent<T>() where T : BaseActorComponent, new()
        {
            var newComponent = new T();
            newComponent.SetOwner(this);
            newComponent.InitializeComponent();
            return newComponent;
        }

        protected bool TryGetComponent<T>(out T targetComponent) where T : BaseActorComponent
        {
            targetComponent = null;
            if (!_componentContainer.TryGetValue(typeof(T), out var baseComponent))
                return false;
            targetComponent = baseComponent as T;
            return true;
        }

        protected override void DisposeManagedResources()
        {
            DisposeComponents();
        }

        private void DisposeComponents()
        {
            if (_componentContainer == null)
                return;

            foreach (var component in _componentContainer.Values)
                component.Dispose();
            _componentContainer.Clear();
            _componentContainer = null;
        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}
