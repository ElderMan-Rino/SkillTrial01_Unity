using Elder.Core.AssetLoader.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Interfaces;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.GameAsset.Interfaces;
using Elder.Core.GameLevel.Interfaces;
using Elder.Core.Loading.Interfaces.Feedback;
using Elder.Core.Logging.Interfaces;
using Elder.Core.UI.Interfaces;
using Elder.Platform.AssetLoader.Infrastructure;
using Elder.Platform.GameAsset.Infrastructure;
using Elder.Platform.GameLevel.Infrastructure;
using Elder.Platform.Loading.Infrastructure.Feedback;
using Elder.Platform.Logging.Infrastructure;
using Elder.Platform.UI.Infrastructure;
using System;
using System.Collections.Generic;

namespace Elder.Platform.CoreFrame.Infrastructure.Factories
{
    public class InfrastructureFactory : DisposableBase, IInfrastructureFactory
    {
        private Dictionary<Type, Func<IInfrastructure>> _constructers;

        public InfrastructureFactory()
        {
            InitializeConstructerContainer();
            RegistPersistentConstructers();
        }

        private void InitializeConstructerContainer()
        {
            _constructers = new();
        }

        private void RegistPersistentConstructers()
        {
            Register<ILogEventDispatcher>(() => new LoggingInfrastructure());
            Register<IGameLevelExecutor>(() => new SceneLoader());
            Register<IUIViewInfrastructure>(() => new UIViewInfrastructure());
            Register<ILoadingProgressTracker>(() => new LoadingProgressTracker());
            Register<IAssetLoader>(() => new AddressableLoader());
            Register<IAssetRepository>(() => new AssetRepository());
        }

        public void Register<T>(Func<IInfrastructure> constructer) where T : IInfrastructure
        {
            _constructers.TryAdd(typeof(T), constructer);
        }

        public bool TryCreateInfrastructure(Type type, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister, ISubInfrastructureCreator subInfraCreator, IApplicationProvider appProvider, out IInfrastructure infrastructure)
        {
            infrastructure = null;
            if (!_constructers.TryGetValue(type, out var constructer))
                return false;

            infrastructure = constructer.Invoke();
            return infrastructure.TryInitialize(infraProvider, infraRegister, subInfraCreator, appProvider);
        }

        protected override void DisposeManagedResources()
        {
            DisposeConstructers();
        }

        private void DisposeConstructers()
        {
            _constructers.Clear();
            _constructers = null;
        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}