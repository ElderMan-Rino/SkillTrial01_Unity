using Elder.Core.CoreFrame.Application;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Platform.CoreFrame.Infrastructure.Factories;
using Elder.Platform.CoreFrame.Infrastructure;
using System;

namespace Elder.Platform.CoreFrame.Presentation
{
    public sealed class CoreFrameInitializer
    {
        public CoreFrameApplication Initialize(InfrastructureFactory infraFactory, SubInfrastructureFactory subInfraFactory, ApplicationFactory appFactory)
        {
            var coreFrameInfra = CreateCoreFrameInfra(infraFactory, subInfraFactory);
            var coreFrameApp = CreateAndInitializeApplication(coreFrameInfra, appFactory);
            coreFrameInfra.InjectAppProvider(coreFrameApp);

            if (!coreFrameApp.TryInitialize())
                throw new InvalidOperationException("ILogEventDispatcher infrastructure is not initialized or not registered. Please check the log event dispatcher configuration.");


            return coreFrameApp;
        }

        private CoreFrameApplication CreateAndInitializeApplication(CoreFrameInfrastructure infra, ApplicationFactory appFactory)
            => new CoreFrameApplication(infra, infra, infra, appFactory);

        private CoreFrameInfrastructure CreateCoreFrameInfra(IInfrastructureFactory infraFactory, ISubInfrastructureFactory subInfraFactory)
            => new(infraFactory, subInfraFactory);
    }
}