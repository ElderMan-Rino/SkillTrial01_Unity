using Elder.Assignment.Infrastructure;
using Elder.Core.Common.Interfaces;
using Elder.Core.CoreFrame.Application;
using Elder.Platform.CoreFrame.Infrastructure.Factories;
using UnityEngine;

namespace Elder.Platform.CoreFrame.Presentation
{
    public class CoreFrameRunner : MonoBehaviour
    {
        public IContextAdapter ContextAdapter { get; private set; }

        private void Awake()
        {
            RegisterDontDestroyOnLoad();
            InitializeCoreFrame();
        }

        private void InitializeCoreFrame()
        {
            var initializer = new CoreFrameInitializer();
            var infraFactory = CreateInfrastructureFactory();
            var subInfraFactory = CreateSubInfrastructureFactory();
            var appFactory = CreateApplicationFactory();
            var coreFrameApp = initializer.Initialize(infraFactory, subInfraFactory, appFactory);
            coreFrameApp.StartGameFlow();
            ContextAdapter = coreFrameApp;
        }

        private InfrastructureFactory CreateInfrastructureFactory()
        {
            var infraFactory = new InfrastructureFactory();
            var assignmentInfraInstaller = new AssignmentInfraInstaller();
            assignmentInfraInstaller.Install(infraFactory);
            return infraFactory;
        }

        private SubInfrastructureFactory CreateSubInfrastructureFactory()
        {
            var subInfrastructureFactory = new SubInfrastructureFactory();
            var assignmentSubInfraInstaller = new AssignmentSubInfraInstaller();
            assignmentSubInfraInstaller.Install(subInfrastructureFactory);
            return subInfrastructureFactory;
        }

        private ApplicationFactory CreateApplicationFactory()
        {
            var appFactory = new ApplicationFactory();
            var assignmentAppInstaller = new AssignmentAppInstaller();
            assignmentAppInstaller.Install(appFactory);
            return appFactory;
        }

        private void RegisterDontDestroyOnLoad()
        {
            DontDestroyOnLoad(this);
        }

        public bool TryRequireApplication<T>() where T : class, IApplication
        {
            return ContextAdapter.TryRequireApplication<T>(); 
        }

        private void OnApplicationQuit()
        {
            DisposeApplication();
        }

        private void DisposeApplication()
        {
            ContextAdapter?.Dispose();
            ContextAdapter = null;
        }
    }
}
