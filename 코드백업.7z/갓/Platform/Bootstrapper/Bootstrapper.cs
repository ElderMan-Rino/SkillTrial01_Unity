using Elder.Core.Common.Constant;
using Elder.Platform.CoreFrame.Presentation;
using UnityEngine;

namespace Elder.Platform.Bootstrapper
{
    public static class Bootstrapper
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSplashScreen)]
        public static void Entry()
        {
            CreateCoreFrameRunner();
        }

        private static void CreateCoreFrameRunner()
        {
            var mainFrameworkName = CoreConstants.MAIN_FRAMEWORK_NAME;
            if (GameObject.Find(mainFrameworkName))
                return;

            var runnerGo = new GameObject(mainFrameworkName);
            runnerGo.AddComponent<CoreFrameRunner>();
        }
    }
}