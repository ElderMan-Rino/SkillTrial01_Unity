using Cysharp.Threading.Tasks;
using Elder.Core.AssetLoader.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace Elder.Platform.AssetLoader.Infrastructure
{
    public class AddressableLoader : InfrastructureBase, IAssetLoader
    {
        private Dictionary<string, AsyncOperationHandle> _loadedHandles;
        public override InfrastructureType InfraType => InfrastructureType.Persistent;

        public override bool TryInitialize(IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister, ISubInfrastructureCreator subInfraCreator, IApplicationProvider appProvider)
        {
            if (!base.TryInitialize(infraProvider, infraRegister, subInfraCreator, appProvider))
                return false;
            
            InitializeHandleContainer();
            return true;
        }

        private void InitializeHandleContainer()
        {
            _loadedHandles = new();
        }

        public async Task<T> LoadAsync<T>(string key) where T : class
        {
            return await LoadInternalAsync<T>(key);
        }

        private async UniTask<T> LoadInternalAsync<T>(string key) where T : class
        {
            if (_loadedHandles.TryGetValue(key, out var handle))
            {
                if (handle.IsValid() && handle.Result is T result)
                    return result;
            }

            var opHandle = Addressables.LoadAssetAsync<UnityEngine.Object>(key);
            try
            {
                var unityObject = await opHandle.ToUniTask();
                if (opHandle.Status == AsyncOperationStatus.Succeeded)
                {
                    if (unityObject is T result)
                    {
                        if (!_loadedHandles.ContainsKey(key))
                            _loadedHandles.Add(key, opHandle);
                        return result;
                    }
                    else
                    {
                        _logger.Error($"[AddressableLoader] Type Mismatch! Key: {key}, Loaded: {unityObject.GetType().Name}, Expected: {typeof(T).Name}");
                        Addressables.Release(opHandle);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Addressables.Release(opHandle);
                _logger.Error($"[AddressableLoader] Failed to load asset: {key}. Error: {ex.Message}");
            }
            return null;
        }

        public async Task<IList<T>> LoadByLabelAsync<T>(string label) where T : class
        {
            return await LoadByLabelInternalAsync<T>(label);
        }

        private async UniTask<IList<T>> LoadByLabelInternalAsync<T>(string label) where T : class
        {
            if (_loadedHandles.TryGetValue(label, out var handle))
            {
                if (handle.IsValid() && handle.Result is IList<UnityEngine.Object> cachedList)
                {
                    try
                    {
                        return cachedList.OfType<T>().ToList();
                    }
                    catch
                    {
                        _loadedHandles.Remove(label);
                    }
                }
                else
                {
                    _loadedHandles.Remove(label);
                }
            }

            var opHandle = Addressables.LoadAssetsAsync<UnityEngine.Object>(label, null);
            try
            {
                IList<UnityEngine.Object> unityObjects = await opHandle.ToUniTask();
                if (opHandle.Status == AsyncOperationStatus.Succeeded)
                {
                    List<T> resultList = unityObjects.OfType<T>().ToList();
                    if (resultList != null)
                    {
                        if (!_loadedHandles.ContainsKey(label))
                        {
                            _loadedHandles.Add(label, opHandle);
                        }
                        return resultList;
                    }
                }
                Addressables.Release(opHandle);
                _logger.Error($"[AddressableLoader] Failed to load label or cast types: {label}");
            }
            catch (System.Exception ex)
            {
                Addressables.Release(opHandle);
                _logger.Error($"[AddressableLoader] Exception loading label {label}: {ex.Message}");
            }
            return null;
        }

        public void Release(string key)
        {
            if (_loadedHandles.TryGetValue(key, out var handle))
            {
                Addressables.Release(handle);
                _loadedHandles.Remove(key);
            }
            else
            {
                _logger.Warning($"[AddressableLoader] Trying to release unknown key: {key}");
            }
        }

        protected override void DisposeManagedResources()
        {
            foreach (var handle in _loadedHandles.Values)
                Addressables.Release(handle);
            _loadedHandles.Clear();
            _loadedHandles = null;

            base.DisposeManagedResources();
        }

      
    }
}