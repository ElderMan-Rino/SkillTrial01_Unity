using Elder.Core.Common.Interfaces;

namespace Elder.Platform.Logging.Interfaces
{
    public interface IUnityLogAdapter : ISubInfrastructure
    {
        
    }
}