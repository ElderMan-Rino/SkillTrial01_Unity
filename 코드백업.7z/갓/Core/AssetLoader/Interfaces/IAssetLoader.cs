using Elder.Core.Common.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Elder.Core.AssetLoader.Interfaces
{
    public interface IAssetLoader : IInfrastructure
    {
        public Task<T> LoadAsync<T>(string key) where T : class;
        public Task<IList<T>> LoadByLabelAsync<T>(string label) where T : class;
        public void Release(string key);
    }
}