using Elder.Core.Common.Interfaces;
using UnityEngine;

namespace Elder.Core.ActorManager.Interfaces
{
    public interface IActorManagerApp : IApplication
    {
        
    }
}