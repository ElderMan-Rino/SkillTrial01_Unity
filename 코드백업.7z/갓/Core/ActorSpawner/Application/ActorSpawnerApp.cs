using Elder.Core.ActorSpawner.Data;
using Elder.Core.ActorSpawner.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.GameAsset.Interfaces;
using Elder.Platform.Actors.BaseClasses;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Elder.Core.ActorSpawner.Application
{
    public class ActorSpawnerApp : ApplicationBase, IActorSpawnerApp
    {
        public override ApplicationType AppType => ApplicationType.Scene;

        public bool TrySpawnActors(ISpawnDataProvider spawnDataProvider, out IList<BaseActor> spawnActors)
        {
            spawnActors = null;
            if (!TryGetInfrastructure<IAssetRepository>(out var assetRepository))
            {
                _logger.Error($"Failed to retrieve infrastructure: {nameof(IAssetRepository)}. It may not be registered or initialized properly.");
                return false;
            }

            

            if (!spawnDataProvider.TryGetSpawnInfos(out var spawnInfos))
            {
                _logger.Error($"Failed to retrieve SpawnInfos from {nameof(ISpawnDataProvider)}. Ensure the spawn data is loaded correctly.");
                return false;
            }

            spawnActors = new List<BaseActor>();
            foreach (var spawnInfo in spawnInfos)
            {
                if (!TryCreateActor(spawnInfo))
                    return false;
            }
            return spawnActors.Count > 0;
        }

        private bool TryCreateActor(in SpawnInfo spawninfo)
        {
            return true;
        }

        protected override void DisposeSubTokens()
        {

        }
    }
}