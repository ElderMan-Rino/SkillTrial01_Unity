using Elder.Core.ActorSpawner.Data;
using System.Collections.Generic;

namespace Elder.Core.ActorSpawner.Interfaces
{
    public interface ISpawnDataProvider 
    {
        public bool TryGetSpawnInfos(out IList<SpawnInfo> spawnInfos);
    }
}