using Elder.Core.Common.Interfaces;
using Elder.Platform.Actors.BaseClasses;
using System.Collections.Generic;

namespace Elder.Core.ActorSpawner.Interfaces
{
    public interface IActorSpawnerApp : IApplication
    {
        public bool TrySpawnActors(ISpawnDataProvider spawnInfo, out IList<BaseActor> spawnActors);
    }
}
