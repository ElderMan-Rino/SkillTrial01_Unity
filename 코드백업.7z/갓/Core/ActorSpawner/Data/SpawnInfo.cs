using UnityEngine;

namespace Elder.Core.ActorSpawner.Data
{
    public readonly struct SpawnInfo
    {
        public readonly int ActorIndex;
        public readonly Vector3 Position;
        public readonly Quaternion Rotation;
        public readonly Transform Root;

        public SpawnInfo(int actorIndex, Transform spawnPoint, Transform root)
        {
            ActorIndex = actorIndex;
            Position = spawnPoint.position;
            Rotation = spawnPoint.rotation;
            Root = root;
        }
    }
}