using Elder.Core.Common.Interfaces;

namespace Elder.Core.Loading.Interfaces.Status
{
    public interface ILoadingStatusProvider : IInfrastructure
    {
        
    }
}