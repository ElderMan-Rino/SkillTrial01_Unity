namespace Elder.Core.Loading.Interfaces.Status
{
    public interface ILoadingStatusReporter 
    {

    }
}