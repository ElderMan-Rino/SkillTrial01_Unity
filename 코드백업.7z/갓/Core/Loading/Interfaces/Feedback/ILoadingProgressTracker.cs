using Elder.Core.Common.Interfaces;

namespace Elder.Core.Loading.Interfaces.Feedback
{
    public interface ILoadingProgressTracker : IInfrastructure
    {

    }
}