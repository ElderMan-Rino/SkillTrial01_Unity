using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.FluxMessage.Interfaces;
using Elder.Core.Loading.Interfaces.Feedback;
using Elder.Core.Loading.Messages;
using System;

namespace Elder.Core.Loading.Application.Feedback
{
    public class LoadingFeedbackApplication : ApplicationBase, ILoadingFeedbackApplication
    {
        private IDisposable _loadingStartedSubToken;
        private ILoadingProgressTracker _loadingProgressTracker;

        public override ApplicationType AppType => ApplicationType.Persistent;
        
        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            return base.TryInitialize(appProvider, infraProvider, infraRegister);
        }
        
        public override bool TryPostInitialize()
        {
            if (!TrySubscribeToStartLoadingFeedback())
                return false;

            return base.TryPostInitialize();
        }

        private bool TrySubscribeToStartLoadingFeedback()
        {
            if (!TryGetApplication<IFluxRouter>(out var fluxRouter))
                return false;

            _loadingStartedSubToken = fluxRouter.Subscribe<FxLoadingStarted>(HandleFxLoadingStared, FluxPhase.Normal);
            return _loadingStartedSubToken != null;
        }

        private void HandleFxLoadingStared(in FxLoadingStarted message)
        {
            // ���⼭ UI ���� ��û ó�� 
        }

        protected override void DisposeSubTokens()
        {
            DisposeLoadingSubToken();
        }

        private void DisposeLoadingSubToken()
        {
            _loadingStartedSubToken?.Dispose();
            _loadingStartedSubToken = null;
        }
    }
}