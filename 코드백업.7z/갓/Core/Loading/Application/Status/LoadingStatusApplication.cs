using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.Loading.Interfaces.Status;
using System;
using System.Collections.Generic;

namespace Elder.Core.Loading.Application.Status
{
    public class LoadingStatusApplication : ApplicationBase, ILoadingStatusApplication
    {
        private ILoadingStatusProvider _loadingStatusProvider;
        private Dictionary<Type, ILoadingStatusReporter> _statusReporters;

        public override ApplicationType AppType => ApplicationType.Persistent; 

        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            if (!base.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;

            InitializeReportersContainer();
            return true;
        }
       
        private void InitializeReportersContainer()
        {
            _statusReporters = new();
        }

        public bool TryRegisterReporter<T>(T reporter) where T : class, ILoadingStatusReporter
        {
            var type = typeof(T);
            if (!_statusReporters.TryAdd(type, reporter))
            {
                _logger.Error($"Failed to register loading status reporter. Reporter of type '{type.FullName}' is already registered.");
                return false;
            }
            return true;
        }

        protected override void DisposeManagedResources()
        {
            ClearStatusReporters();
            base.DisposeManagedResources();
        }

        private void ClearStatusReporters()
        {
            _statusReporters.Clear();
            _statusReporters = null;
        }

        protected override void DisposeSubTokens()
        {

        }
    }
}