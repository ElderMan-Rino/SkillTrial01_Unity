using Elder.Core.FluxMessage.Interfaces;

namespace Elder.Core.Loading.Messages
{
    public readonly struct FxLoadingStarted : IFluxMessage
    {

    }
}