using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.FluxMessage.Interfaces;
using Elder.Core.GameLevel.Messages;
using Elder.Core.UI.Interfaces;
using System;

namespace Elder.Core.UI.Application
{
    public class UIAppService : ApplicationBase, IUIAppService
    {
        private IUIViewInfrastructure _uiViewInfra;
        private IDisposable _loadGameLevelStateSubToken;

        public override ApplicationType AppType => ApplicationType.Persistent;

        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            if (!base.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;

            RequireUIViewInfra();
            return true;
        }
  
        private void RequireUIViewInfra()
        {
            RequireInfrastructure<IUIViewInfrastructure>();
        }

        public override bool TryPostInitialize()
        {
            if (!TryBindUIViewInfra())
                return false;

            if (!TrySubscribeToLoadGameLevelState())
                return false;

            return true;
        }

        private bool TrySubscribeToLoadGameLevelState()
        {
            if (!TryGetApplication<IFluxRouter>(out var fluxRouter))
                return false;

            _loadGameLevelStateSubToken = fluxRouter.Subscribe<FxLoadGameLevelState>(HandleFxLoadGameLevelState, FluxPhase.Pre);
            return true;
        }

        private void HandleFxLoadGameLevelState(in FxLoadGameLevelState message)
        {
            if (message.CurrentLoadState != LoadGameLevelState.UnloadLoading)
                return;

            RequestRegisterViews();
        }

        private void RequestRegisterViews()
        {
            _uiViewInfra.RegisterViews();
        }

        private bool TryBindUIViewInfra()
        {
            if (!TryGetInfrastructure<IUIViewInfrastructure>(out var uiViewInfra))
            {
                _logger.Error("Failed to retrieve IUIViewInfrastructure from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _uiViewInfra = uiViewInfra;
            return true;
        }

        protected override void DisposeSubTokens()
        {
            DisposeLoadGameLevelStateSubToken();
        }

        private void DisposeLoadGameLevelStateSubToken()
        {
            _loadGameLevelStateSubToken.Dispose();
            _loadGameLevelStateSubToken = null;
        }

        protected override void DisposeManagedResources()
        {
            ClearUIViewInfra();
        }

        private void ClearUIViewInfra()
        {
            _uiViewInfra = null;
        }

      
    }
}