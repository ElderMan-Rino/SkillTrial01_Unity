namespace Elder.Core.Common.Constant
{
    public static class CoreConstants
    {
        public const string MAIN_FRAMEWORK_NAME = "[MainFramework]";
    }
}