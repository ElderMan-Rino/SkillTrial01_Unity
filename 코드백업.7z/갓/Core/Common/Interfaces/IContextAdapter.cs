using System;

namespace Elder.Core.Common.Interfaces
{
    public interface IContextAdapter : IDisposable
    {
        public bool TryRequireApplication<T>() where T : class, IApplication;
        public bool TryEnsureApplication<T>(out T targetApp) where T : class, IApplication;
        public bool TryEnsureInfrastructure<T>(out T targetInfra) where T : class, IInfrastructure;
    }
}