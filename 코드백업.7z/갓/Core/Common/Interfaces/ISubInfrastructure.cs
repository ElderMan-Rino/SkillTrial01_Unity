using System;

namespace Elder.Core.Common.Interfaces
{
    public interface ISubInfrastructure : IDisposable
    {

    }
}