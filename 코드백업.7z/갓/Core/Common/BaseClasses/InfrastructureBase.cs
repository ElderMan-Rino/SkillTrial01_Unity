using Elder.Core.Common.Enums;
using Elder.Core.Common.Interfaces;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.Logging.Helpers;
using Elder.Core.Logging.Interfaces;

namespace Elder.Core.Common.BaseClasses
{
    public abstract class InfrastructureBase : DisposableBase, IInfrastructure
    {
        private IInfrastructureProvider _infraProvider;
        private IInfrastructureRegister _infraRegister;
        private ISubInfrastructureCreator _subInfraCreator;
        private IApplicationProvider _appProvider;

        protected ILoggerEx _logger;

        protected virtual bool _useLogger { get; } = true;

        public abstract InfrastructureType InfraType { get; }
        

        public virtual bool TryInitialize(IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister, ISubInfrastructureCreator subInfraCreator, IApplicationProvider appProvider)
        {
            InjectInfraProvider(infraProvider);
            InjectInfraRegister(infraRegister);
            InjectSubInfraCreator(subInfraCreator);
            InjectAppProvider(appProvider);

            if (!TryBindLogger())
                return false;
            
            return true;
        }

        protected bool TryBindLogger()
        {
            if (!_useLogger) 
                return true;

            _logger = LogFacade.GetLoggerFor(this.GetType());
            return _logger != null;
        }

        private void InjectAppProvider(IApplicationProvider appProvider)
        {
            _appProvider = appProvider; 
        }
       
        private void InjectSubInfraCreator(ISubInfrastructureCreator subInfraCreator)
        {
            _subInfraCreator = subInfraCreator;
        }
        
        private void InjectInfraProvider(IInfrastructureProvider infraProvider)
        {
            _infraProvider = infraProvider;
        }
        
        private void InjectInfraRegister(IInfrastructureRegister infraRegister)
        {
            _infraRegister = infraRegister;
        }
        
        protected bool TryGetInfrastructure<T>(out T targetInfrastructure) where T : class, IInfrastructure
        {
            return _infraProvider.TryGetInfrastructure<T>(out targetInfrastructure);
        }
        
        protected void RegisterInfrastructure<T>() where T : IInfrastructure
        {
            _infraRegister.RegisterInfrastructure<T>();
        }

        protected bool TryCreateSubInfra<T>(out ISubInfrastructure subInfra) where T : ISubInfrastructure
        {
            return _subInfraCreator.TryCreateSubInfra<T>(out subInfra);
        }

        protected bool TryGetApplication<T>(out T targetApplication) where T : class, IApplication
        {
            return _appProvider.TryGetApplication<T>(out targetApplication);
        }

        protected override void DisposeManagedResources()
        {
            ClearAppProvider();
            ClearSubInfraCreator();
            ClearInfraRegister();
            ClearInfraProvider();
        }

        private void ClearAppProvider()
        {
            _appProvider = null;
        }
        
        private void ClearSubInfraCreator()
        {
            _subInfraCreator = null;
        }
        
        private void ClearInfraRegister()
        {
            _infraRegister = null;
        }

        private void ClearInfraProvider()
        {
            _infraProvider = null;
        }

        protected override void DisposeUnmanagedResources()
        {

        }

        public virtual void PreDispose()
        {

        }

        protected override void CompleteDispose()
        {
            ClearLogger();
        }

        private void ClearLogger()
        {
            _logger = null;
        }
    }
}