namespace Elder.Core.Common.Enums
{
    public enum LogLevel
    {
        Debug,   // �Ǵ� Log
        Info,
        Warning,
        Error
    }
}
