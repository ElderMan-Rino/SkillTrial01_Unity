namespace Elder.Core.Common.Enums
{
    public enum ViewType 
    {
        None,
        Panel,
        Popup,
        Widget,
        System,
        WorldElement,
    }
}