namespace Elder.Core.Common.Enums
{
    public enum InfrastructureType
    {
        Persistent,
        Scene,
        Log,
    }
}