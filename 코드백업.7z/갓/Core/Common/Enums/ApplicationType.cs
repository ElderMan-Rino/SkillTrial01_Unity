namespace Elder.Core.Common.Enums
{
    public enum ApplicationType
    {
        Persistent,
        Scene,
    }
}
