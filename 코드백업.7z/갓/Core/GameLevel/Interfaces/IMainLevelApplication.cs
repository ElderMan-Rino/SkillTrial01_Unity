using Elder.Core.Common.Interfaces;

namespace Elder.Core.GameLevel.Interfaces
{
    public interface IMainLevelApplication : IApplication
    {
      
    }
}