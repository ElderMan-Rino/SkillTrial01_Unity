using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.FluxMessage.Interfaces;
using Elder.Core.GameLevel.Interfaces;
using Elder.Core.GameLevel.Messages;
using Elder.Core.Loading.Messages;
using System;

namespace Elder.Core.GameLevel.Application
{
    public class MainLevelApplication : ApplicationBase, IMainLevelApplication
    {
        private IGameLevelExecutor _gameLevelExecutor;
        private IDisposable _gameLevelChangeSubToken;

        public override ApplicationType AppType => ApplicationType.Persistent;

        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            if (!base.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;

            RequireGameStepInfra();
            return true;
        }

        private void RequireGameStepInfra()
        {
            RequireInfrastructure<IGameLevelExecutor>();
        }

        public override bool TryPostInitialize()
        {
            if (!TrySubscribeToGameLevelChange())
                return false;

            if (!TryBindGameLevelExecutor())
                return false;

            return true;
        }

        private bool TrySubscribeToGameLevelChange()
        {
            if (!TryGetApplication<IFluxRouter>(out var fluxRouter))
                return false;

            _gameLevelChangeSubToken = fluxRouter.Subscribe<FxRequestMainLevelChange>(HandleFxRequestGameLevelChange, FluxPhase.Normal);
            return true;
        }

        private void HandleFxRequestGameLevelChange(in FxRequestMainLevelChange message)
        {
            NotifyLoadingStarted();
            RequestGameLevelChange(message.MainLevelKey);
        }

        private void NotifyLoadingStarted()
        {
            if (!TryGetApplication<IFluxRouter>(out var fluxRouter))
                return;

            fluxRouter.Publish<FxLoadingStarted>(new FxLoadingStarted());
        }

        private void RequestGameLevelChange(string gameLevelKey)
        {
            _gameLevelExecutor.RequestGameLevelChange(gameLevelKey);
        }

        private bool TryBindGameLevelExecutor()
        {
            if (!TryGetInfrastructure<IGameLevelExecutor>(out var gameLevelExecutor))
            {
                _logger.Error("Failed to retrieve IGameLevelExecutor from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _gameLevelExecutor = gameLevelExecutor;
            return _gameLevelExecutor != null;
        }

        protected override void DisposeManagedResources()
        {
            ClearGameLevelExecutor();
            base.DisposeManagedResources();
        }

        protected override void DisposeSubTokens()
        {
            DisposeGameLevelChangeSubToken();
        }

        private void DisposeGameLevelChangeSubToken()
        {
            _gameLevelChangeSubToken.Dispose();
            _gameLevelChangeSubToken = null;
        }

        private void ClearGameLevelExecutor()
        {
            _gameLevelExecutor = null;
        }

        
    }
}