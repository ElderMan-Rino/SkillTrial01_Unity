namespace Elder.Core.GameLevel.Constants
{
    public static class GameLevelConstants 
    {
        public const string PRELOAD_SCENE_KEY = "PreloadScene";
        public const string LOADING_SCENE_KEY = "LoadingScene";
        public const string INGAME_SCENE_KEY = "InGameScene";
    }
}