using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Interfaces;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.FluxMessage.Application;
using Elder.Core.FluxMessage.Interfaces;
using Elder.Core.GameAsset.Application;
using Elder.Core.GameAsset.Interfaces;
using Elder.Core.GameLevel.Application;
using Elder.Core.GameLevel.Interfaces;
using Elder.Core.Loading.Application.Feedback;
using Elder.Core.Loading.Interfaces.Feedback;
using Elder.Core.Logging.Application;
using Elder.Core.Logging.Interfaces;
using Elder.Core.UI.Application;
using Elder.Core.UI.Interfaces;
using System;
using System.Collections.Generic;

namespace Elder.Core.CoreFrame.Application
{
    public class ApplicationFactory : DisposableBase, IApplicationFactory
    {
        private Dictionary<Type, Func<IApplication>> _constructers;

        public ApplicationFactory()
        {
            InitializeConstructerContainer();
            RegistPersistentConstructers();
        }

        private void InitializeConstructerContainer()
        {
            _constructers = new();
        }

        private void RegistPersistentConstructers()
        {
            Register<ILoggerPublisher>(() => new LogApplication());
            Register<IFluxRouter>(() => new FluxRouter());
            Register<IMainLevelApplication>(() => new MainLevelApplication());
            Register<IUIAppService>(() => new UIAppService());
            Register<ILoadingFeedbackApplication>(() => new LoadingFeedbackApplication());
            Register<IGameAssetApp>(() => new GameAssetApplication());
        }

        public void Register<T>(Func<IApplication> constructer) where T : IApplication
        {
            _constructers.TryAdd(typeof(T), constructer);
        }

        public bool TryCreateApplication(Type type, IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister, out IApplication application)
        {
            if (!_constructers.TryGetValue(type, out var constructer))
            {
                application = null;
                return false;
            }
            application = constructer.Invoke();
            if (!application.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;
            return true;
        }

        protected override void DisposeManagedResources()
        {
            DisposeConstructers();
        }

        private void DisposeConstructers()
        {
            _constructers.Clear();
            _constructers = null;
        }

        protected override void DisposeUnmanagedResources()
        {

        }
    }
}