namespace Elder.Core.Preload.Constant
{
    public static class PreloadConstants 
    {
        public const string PRELOAD_LABEL = "Preload";
    }
}