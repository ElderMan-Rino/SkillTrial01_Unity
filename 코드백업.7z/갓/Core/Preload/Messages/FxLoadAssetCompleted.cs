using Elder.Core.FluxMessage.Interfaces;

namespace Elder.Core.Preload.Messages
{
    public readonly struct FxLoadAssetCompleted : IFluxMessage
    {

    }
}