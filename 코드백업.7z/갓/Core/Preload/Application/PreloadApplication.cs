using Elder.Core.AssetLoader.Interfaces;
using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.CoreFrame.Interfaces;
using Elder.Core.FluxMessage.Interfaces;
using Elder.Core.GameAsset.Interfaces;
using Elder.Core.GameLevel.Constants;
using Elder.Core.GameLevel.Messages;
using Elder.Core.Preload.Constant;
using Elder.Core.Preload.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Elder.Core.Preload.Application
{
    public class PreloadApplication : ApplicationBase, IPreloadApp
    {
        private IAssetLoader _assetLoader;
        private IAssetRepository _assetRepository;
        private IDisposable _preloadTask;

        public override ApplicationType AppType => ApplicationType.Scene;

        public override bool TryInitialize(IApplicationProvider appProvider, IInfrastructureProvider infraProvider, IInfrastructureRegister infraRegister)
        {
            if (!base.TryInitialize(appProvider, infraProvider, infraRegister))
                return false;

            RequireInfrastructure<IAssetLoader>();
            RequireInfrastructure<IAssetRepository>();
            return true;
        }

        public override bool TryPostInitialize()
        {
            if (!base.TryPostInitialize())
                return false;

            if (!TryBindAssetLoader())
                return false;

            if (!TryBindAssetRepository())
                return false;

            RunPreloadFlow();
            return true;
        }

        private bool TryBindAssetLoader()
        {
            if (!TryGetInfrastructure<IAssetLoader>(out var assetLoader))
            {
                _logger.Error("Failed to retrieve IAssetLoader from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _assetLoader = assetLoader;
            return _assetLoader != null;
        }

        private bool TryBindAssetRepository()
        {
            if (!TryGetInfrastructure<IAssetRepository>(out var assetRepository))
            {
                _logger.Error("Failed to retrieve IAssetRepository from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _assetRepository = assetRepository;
            return _assetRepository != null;
        }

        private void RunPreloadFlow()
        {
            if (_preloadTask != null)
                return;

            _preloadTask = RunPreloadFlowAsync();
        }

        private async Task RunPreloadFlowAsync()
        {
            var preloadAssets = await LoadPreloadLabelAssetsAsync();
            RegisterAssets(preloadAssets);
            RequestChangeInGameScene();
        }
       
        private async Task<IList<UnityEngine.Object>> LoadPreloadLabelAssetsAsync()
        {
            return await _assetLoader.LoadByLabelAsync<UnityEngine.Object>(PreloadConstants.PRELOAD_LABEL);
        }

        private void RegisterAssets(IList<UnityEngine.Object> preloadAssets)
        {
            if (preloadAssets == null)
                return;

            foreach (var preloadAsset in preloadAssets)
            {
                if (preloadAsset == null)
                    continue;

                _assetRepository.TryAddAsset(preloadAsset.name, preloadAsset);
            }
        }

        private void RequestChangeInGameScene()
        {
            if (!TryGetApplication<IFluxRouter>(out var fluxRouter))
            {
                _logger.Error("Failed to run initial scene: IFluxRouter is not registered in the application. Please ensure the messaging infrastructure is initialized before requesting scene changes.");
                return;
            }
            fluxRouter.Publish<FxRequestMainLevelChange>(new FxRequestMainLevelChange(GameLevelConstants.INGAME_SCENE_KEY));
        }

        protected override void DisposeSubTokens()
        {

        }

        protected override void DisposeManagedResources()
        {
            ClearAssetLoader();
            ClearAssetRepository();
            DisposePreloadTask();
            base.DisposeManagedResources();
        }

        private void ClearAssetLoader()
        {
            _assetLoader = null;
        }

        private void ClearAssetRepository()
        {
            _assetRepository = null;
        }

        private void DisposePreloadTask()
        {
            _preloadTask?.Dispose();
            _preloadTask = null;
        }
    }
}