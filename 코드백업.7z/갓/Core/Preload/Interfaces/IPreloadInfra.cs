using Elder.Core.Common.Interfaces;

namespace Elder.Core.Preload.Interfaces
{
    public interface IPreloadInfra : IInfrastructure
    {

    }
}