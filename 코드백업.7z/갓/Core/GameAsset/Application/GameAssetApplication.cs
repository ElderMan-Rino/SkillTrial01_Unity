using Elder.Core.Common.BaseClasses;
using Elder.Core.Common.Enums;
using Elder.Core.GameAsset.Interfaces;

namespace Elder.Core.GameAsset.Application
{
    public class GameAssetApplication : ApplicationBase, IGameAssetApp
    {
        private IAssetRepository _assetRepository;

        public override ApplicationType AppType => ApplicationType.Persistent;

        public override bool TryPostInitialize()
        {
            if (!base.TryPostInitialize())
                return false;
            
            if (!TryBindAssetRepository())
                return false;

            return true;
        }

        private bool TryBindAssetRepository()
        {
            if (!TryGetInfrastructure<IAssetRepository>(out var assetRepository))
            {
                _logger.Error("Failed to retrieve IAssetRepository from infrastructure. It may not be initialized or registered.");
                return false;
            }
            _assetRepository = assetRepository;
            return true;
        }

        public bool TryGetAsset<T>(string key, out T targetAsset) where T : class
        {
            return _assetRepository.TryGetAsset<T>(key, out targetAsset);
        }

        protected override void DisposeSubTokens()
        {

        }

        protected override void DisposeManagedResources()
        {
            ClearAssetRepository();
            base.DisposeManagedResources();
        }

        private void ClearAssetRepository()
        {
            _assetRepository = null;
        }
    }
}