using Elder.Core.Common.Interfaces;

namespace Elder.Core.GameAsset.Interfaces
{
    public interface IGameAssetApp : IApplication
    {
        public bool TryGetAsset<T>(string key, out T targetAsset) where T : class;
    }
}