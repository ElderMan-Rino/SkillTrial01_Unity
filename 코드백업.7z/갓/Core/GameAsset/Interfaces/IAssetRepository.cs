using Elder.Core.Common.Interfaces;

namespace Elder.Core.GameAsset.Interfaces
{
    public interface IAssetRepository : IInfrastructure
    {
        public bool TryGetAsset<T>(string key, out T targetAsset) where T : class;
        public bool TryAddAsset<T>(string key, T targetAsset) where T : class;
    }
}