namespace Elder.Core.FluxMessage.Interfaces
{
    public interface IFluxMessage {}
}